# sendat
AT 命令工具
1简化使用AT命令请求方式
使用命令说明
sendat 2 'ATI'  2表示 /dev/ttyUSB2  'ATI' 为at命令
